package com.uniquindio.software.clinica.modelo;

public enum EstadoPqrs {
    Nuevo,
    EnProceso,
    Resuelto,
    Archivado
}
