package com.uniquindio.software.clinica.modelo;

public enum TipoExamen {
    ExamenLaboratorio,
    ExamenEspecializado
}
