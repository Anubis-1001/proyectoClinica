package com.uniquindio.software.clinica.servicios;

public interface MedicoHasJornadaService {
    int obtenerIdJornada(String cedulaMedico);

}
